const forElement = document.getElementById("saveBook");

formElement.addEventListener("submit", (event) => {
  event.preventDefault();
  let bookTittle = document.getElementById("bookTittle").value;
  let bookPlot = document.getElementById("bookPlot").value;
  let registry = {
    registryDescription: registryDescription,
    registryBookTittle: registryBookTittle,
  };
  let registryJson = JSON.stringify(registry);
  //Mandar el registryJson al backend y guardarlo allí
  fetch("http://localhost:3000/registry", {
    method: "Post",
    body: registryJson
  })
    .then(x => console.log("hola"))
})

fetch('http://localhost:3000/registry').then(x => x.json()).then(console.log)