const express = require('express')
const cors = require('cors')

const app = express()
const port = 3000

let registryArr = []

//#region
app.use(
    express.urlencoded({
        extended:true
    })
)

app.use(express.json({
    type: "*/*"
}))

app.use(cors());
//#endregion


//Cuando te hagan un get http://localhost:3000/registry

app.get('/registry', (req, res) => {
    res.send('Hicieron n get a app registry')
})

//Si envían un post http://localhost:3000/registry
app.post('/registry', (req, res) => { 
    let registry = req.body;
    registryArr.push()
    res.send(JSON.stringify("Guardado"));
    console.log(registryArr);
})

app.listen(port, () => {    
console.log('Estoy ejecutándome en http://localhost:${port}')
})
